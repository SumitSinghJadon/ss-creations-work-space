import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { Box, Button, Menu, MenuItem } from '@mui/material';
import { MaterialReactTable, createMRTColumnHelper, useMaterialReactTable } from 'material-react-table';
import Skeleton from 'react-loading-skeleton';
import { toast } from 'react-toastify';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import DjangoConfig from '../../config/Config';
const LineMaster = () => {
    const navigate = useNavigate()
    const userData = useSelector(state => state.User.userData);
    const [tableData, setTableData] = useState([])

    // console.log("userData", userData)

    useEffect(() => {
        fetchPlaningData();

    }, [])


    const fetchPlaningData = () => {
        const userData2 = {
            line_id: userData.id,
        };
        const queryParams = new URLSearchParams(userData2).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/qms_planing2/?${queryParams}`, {
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {
                const responseData = response.data.planing_data
                setTableData(responseData)
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };
    // console.log("buyerData",buyerData)

    const handleExportRows = (rows) => {
        const rowData = rows.map((row) => row.original);
        const swingData ={
            rowData:rowData,
        }
        console.log("swingData",swingData)
        axios.post(`${DjangoConfig.apiUrl}/rtqm/sewing_line_input/`, swingData)
            .then(response => {
                toast.success('Data Saved successful!');

            })
            .catch(error => {
                console.error("Error saving data:", error);
                toast.error("Error saving data:");
            });
    };




    const columnHelper = createMRTColumnHelper();
    const columns = [
        columnHelper.accessor((row, index) => index + 1, { header: 'S/N', size: 40 }),
        columnHelper.accessor('buyer', { header: 'Buyer', size: 20 }),
        columnHelper.accessor('styleno', { header: 'Style No', size: 20 }),
        columnHelper.accessor('color', { header: 'Color ', size: 20 }),
        columnHelper.accessor('quantity', { header: 'Quantity', size: 20 }),
        columnHelper.accessor('delvdate', { header: 'Delivery Date', size: 20 }),
    ];



    const table = useMaterialReactTable({
        columns,
        data: tableData,
        // state: {
        //   isLoading:  isLoading ? <Skeleton count={5} /> : null,

        // },
        enableRowSelection: true,
        columnFilterDisplayMode: 'popover',
        paginationDisplayMode: 'pages',
        positionToolbarAlertBanner: 'bottom',
        renderTopToolbarCustomActions: ({ table }) => (
            <Box
                sx={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px',
                    flexWrap: 'wrap',
                    style: { fontSize: '5px' },
                }}
            >

               
                <Button
                    disabled={
                        !table.getIsSomeRowsSelected() && !table.getIsAllRowsSelected()
                    }
                    //only export selected rows
                    onClick={() => handleExportRows(table.getSelectedRowModel().rows)}
                    startIcon={<FileDownloadIcon />}
                    >
                        Save Data
                </Button>
            </Box>
        ),
    });

    return (
        <div>

            <div className='mt-2'>
                <MaterialReactTable table={table} />
            </div>

        </div>
    );
};

export default LineMaster;
